package Model;

public interface Moveable {
    void move();
}
