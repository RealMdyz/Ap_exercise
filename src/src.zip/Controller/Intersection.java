package Controller;

public class Intersection {

}
